﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double valora, valorb, valorc;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtValorA.Text, out valora) || valora <= 0)
            {
                MessageBox.Show("Valor A inválido");
                txtValorA.Focus();
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out valorb) || valorb <= 0)
            {
                MessageBox.Show("Valor B inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out valorc) || valorc <= 0)
            {
                MessageBox.Show("Valor C inválido");
                txtValorC.Focus();
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
           if (valora + valorb > valorc && Math.Abs(valora - valorb) < valorc && valorb + valorc > valora && Math.Abs (valorb - valorc) < valora && valorc + valora > valorb && Math.Abs(valorc - valora) < valorb)
           {
              if (valora == valorb && valorb == valorc)
              {
                    MessageBox.Show("Equilátero");
              }
              else
              {
                    if(valora != valorb && valorb != valorc)
                    {
                        MessageBox.Show("Escaleno");
                    }
                    else
                    {
                        {
                            MessageBox.Show("Isóceles");
                        }
                    }
              }
            

           }
            else
            {
                MessageBox.Show("Inválido");
            }
            
        }
    

         

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
