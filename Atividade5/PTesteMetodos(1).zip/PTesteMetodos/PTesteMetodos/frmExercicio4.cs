﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (Char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contNum++;
                }
                contador++;
            }
            MessageBox.Show($"O texto tem {contNum} números");
        }

        private void btnCaracterBran_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            MessageBox.Show($"A posição do 1º caracter em branco é {posicao}");
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contLetra = 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if (Char.IsLetter(c))
                {
                    contLetra++;
                }
            }

            MessageBox.Show($"O texto tem {contLetra}");
        }
    }
}
