﻿namespace PFerramentas
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInfoAplic = new System.Windows.Forms.Label();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblIntegrantes = new System.Windows.Forms.Label();
            this.lblNome2 = new System.Windows.Forms.Label();
            this.lblNome3 = new System.Windows.Forms.Label();
            this.lblInfoGrupo = new System.Windows.Forms.Label();
            this.lblNome1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblInfoAplic
            // 
            this.lblInfoAplic.AutoSize = true;
            this.lblInfoAplic.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoAplic.Location = new System.Drawing.Point(13, 22);
            this.lblInfoAplic.Name = "lblInfoAplic";
            this.lblInfoAplic.Size = new System.Drawing.Size(294, 22);
            this.lblInfoAplic.TabIndex = 0;
            this.lblInfoAplic.Text = "Informações sobre a aplicação ";
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(14, 55);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(619, 18);
            this.lblTexto.TabIndex = 1;
            this.lblTexto.Text = "Aplicação com utilização de Banco de Dados em tabela, para cadastro de informaçõe" +
    "s.\r\n";
            this.lblTexto.Click += new System.EventHandler(this.lblInfoApp2_Click);
            // 
            // lblIntegrantes
            // 
            this.lblIntegrantes.AutoSize = true;
            this.lblIntegrantes.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIntegrantes.Location = new System.Drawing.Point(14, 116);
            this.lblIntegrantes.Name = "lblIntegrantes";
            this.lblIntegrantes.Size = new System.Drawing.Size(88, 18);
            this.lblIntegrantes.TabIndex = 3;
            this.lblIntegrantes.Text = "Integrantes:\r\n";
            this.lblIntegrantes.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblNome2
            // 
            this.lblNome2.AutoSize = true;
            this.lblNome2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome2.Location = new System.Drawing.Point(14, 170);
            this.lblNome2.Name = "lblNome2";
            this.lblNome2.Size = new System.Drawing.Size(88, 18);
            this.lblNome2.TabIndex = 4;
            this.lblNome2.Text = "Luiggi Dias";
            // 
            // lblNome3
            // 
            this.lblNome3.AutoSize = true;
            this.lblNome3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome3.Location = new System.Drawing.Point(14, 199);
            this.lblNome3.Name = "lblNome3";
            this.lblNome3.Size = new System.Drawing.Size(95, 18);
            this.lblNome3.TabIndex = 5;
            this.lblNome3.Text = "Mirella Faria";
            this.lblNome3.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblInfoGrupo
            // 
            this.lblInfoGrupo.AutoSize = true;
            this.lblInfoGrupo.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoGrupo.Location = new System.Drawing.Point(13, 85);
            this.lblInfoGrupo.Name = "lblInfoGrupo";
            this.lblInfoGrupo.Size = new System.Drawing.Size(255, 22);
            this.lblInfoGrupo.TabIndex = 6;
            this.lblInfoGrupo.Text = "Informações sobre o grupo";
            // 
            // lblNome1
            // 
            this.lblNome1.AutoSize = true;
            this.lblNome1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome1.Location = new System.Drawing.Point(14, 143);
            this.lblNome1.Name = "lblNome1";
            this.lblNome1.Size = new System.Drawing.Size(102, 18);
            this.lblNome1.TabIndex = 7;
            this.lblNome1.Text = "Lana Mathias";
            this.lblNome1.Click += new System.EventHandler(this.label5_Click);
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.BackgroundImage = global::PFerramentas.Properties.Resources._69839901;
            this.ClientSize = new System.Drawing.Size(833, 437);
            this.Controls.Add(this.lblNome1);
            this.Controls.Add(this.lblInfoGrupo);
            this.Controls.Add(this.lblNome3);
            this.Controls.Add(this.lblNome2);
            this.Controls.Add(this.lblIntegrantes);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblInfoAplic);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInfoAplic;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblIntegrantes;
        private System.Windows.Forms.Label lblNome2;
        private System.Windows.Forms.Label lblNome3;
        private System.Windows.Forms.Label lblInfoGrupo;
        private System.Windows.Forms.Label lblNome1;
    }
}