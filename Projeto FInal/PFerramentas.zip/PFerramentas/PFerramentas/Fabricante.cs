﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PFerramentas
{
    internal class Fabricante
    {
        public int IdFabricante { get; set; }
        public string NomeFantasia { get; set; }


        public DataTable Listar()
        {
            SqlDataAdapter daFabricante;
            DataTable dtFabricante = new DataTable();
            try
            {
                daFabricante = new SqlDataAdapter("SELECT * FROM FABRICANTE", Form1.conexao);
                daFabricante.Fill(dtFabricante);
                daFabricante.FillSchema(dtFabricante, SchemaType.Source);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtFabricante;

        }
        public int Salvar() 
        {
            int retorno = 0;

            try 
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("INSERT INTO FABRICANTE VALUES (@nomeFantasia)", Form1.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nomeFantasia", SqlDbType.VarChar));

                mycommand.Parameters["@nomeFantasia"].Value = NomeFantasia;
                
                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex) 
                {
                throw ex;
                }
            return retorno;
        } 
        public int Alterar()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE FABRICANTE  SET nomeFantasia = @nomeFantasia WHERE id=@idfabricante", Form1.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idfabricante", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@nomeFantasia", SqlDbType.VarChar));

                mycommand.Parameters["@idfabricante"].Value = IdFabricante;
                mycommand.Parameters["@nomeFantasia"].Value = NomeFantasia;

                retorno = mycommand.ExecuteNonQuery();

            }
            catch (Exception ex) { throw ex; }
             return retorno;
        }

        public int Excluir() 
        {
            int retorno = 0;

            try 
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("DELETE FROM FABRICANTE WHERE id=@idfabricante", Form1.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idfabricante", SqlDbType.Int));
                mycommand.Parameters["@idfabricante"].Value = IdFabricante;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            { 
                throw ex; 
            }
            
            return retorno;
        }
    }
}
